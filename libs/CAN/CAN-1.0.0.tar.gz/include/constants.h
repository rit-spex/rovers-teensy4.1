

enum CAN_PINS {
    CAN_RX_PIN = 0,
    CAN_TX_PIN = 1
};
