#ifndef TICT249
#define TICT249

#include <Tic.h>

TicI2C tic;

void delayWhileResettingCommandTimeout(uint32_t ms);

#endif
